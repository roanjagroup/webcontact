<?php $__env->startSection('title', 'Registro'); ?>
<?php $__env->startSection('content'); ?>
	<h3>Este es el registro</h3>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>