@extends('layout')

@section('title', 'Registro')
@section('content')
	<h3>Este es el registro</h3>

@endsection